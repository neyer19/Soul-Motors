<template>
  <div :class="['app-wrapper', isDarkMode ? 'dark-theme' : 'light-theme']">
    <router-view
      :isDarkMode="isDarkMode"
      :userEmail="email"
      @toggle-theme="toggleTheme"
      @change-view="changeView"
      @login="onLogin"
    />
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()
const isDarkMode = ref(true)
const email = ref('') // correo con el que se inició sesión (lo usa MecanicoView)

const toggleTheme = () => { isDarkMode.value = !isDarkMode.value }

// Las vistas emiten 'change-view' con 'login', 'inventario', 'gerente', etc.
const changeView = (name) => { router.push('/' + name) }

// LoginView avisa con qué correo entró
const onLogin = (mail) => { email.value = mail }
</script>

<style>
.dark-theme { --bg-main: #1E1F22; --bg-sidebar: #18191B; --bg-card: #2B2D30; --border-color: #3C3F41; --text-primary: #F2F2F2; --text-secondary: #9DA5B4; --input-bg: #232428; }
.light-theme { --bg-main: #F4F6F8; --bg-sidebar: #FFFFFF; --bg-card: #FFFFFF; --border-color: #CBD5E1; --text-primary: #1E293B; --text-secondary: #64748B; --input-bg: #FFFFFF; }

* { box-sizing: border-box; }
body { margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: var(--bg-main); color: var(--text-primary); }
.app-wrapper { min-height: 100vh; background-color: var(--bg-main); color: var(--text-primary); transition: background-color 0.3s ease; }
</style>
